import React from 'react'
import ReactDOM from 'react-dom/client'

const App = () => {
  return <h1>Bem-vindo ao Camelô Virtual</h1>
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)

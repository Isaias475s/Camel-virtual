// Código principal do Camelô Virtual
console.log('Camelô Virtual');